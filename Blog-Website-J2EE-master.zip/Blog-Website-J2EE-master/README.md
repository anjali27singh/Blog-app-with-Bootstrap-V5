# Blog-Website-J2EE
A Web Application where user can post different blogs by logging into this website. Users can edit their blogs and can also see other people's blog also. Login, Signup facilities are based on MVC Architecture and Session Management.

## Tools and Technologies used:
1. Servlets and JSP with MVC Architecture
2. MYSQL Database
3. Apache Tomcat Server
4. Netbeans 8.2 IDE
